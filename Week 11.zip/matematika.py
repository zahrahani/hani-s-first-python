# konstanta phi
phi = 3.14

# fungsi untuk menghitung luas lingkaran
def Luaslingkaran(r):
    Lling = phi * r * r
    return Lling

# fungsi untuk menghitung luas persegi
def Luaspersegi(s):
    Lper = s * s
    return Lper
