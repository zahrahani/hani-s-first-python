def greeting(name):
    print("Hello, " + name)

person1 = {
  "name"     : "hani",
  "age"      : 18,
  "country"  : "Indonesia"
}